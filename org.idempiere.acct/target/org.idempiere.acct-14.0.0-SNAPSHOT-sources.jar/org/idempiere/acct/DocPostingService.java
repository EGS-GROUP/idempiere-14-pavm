/***********************************************************************
 * This file is part of iDempiere ERP Open Source                      *
 * http://www.idempiere.org                                            *
 *                                                                     *
 * Copyright (C) Contributors                                          *
 *                                                                     *
 * This program is free software; you can redistribute it and/or       *
 * modify it under the terms of the GNU General Public License         *
 * as published by the Free Software Foundation; either version 2      *
 * of the License, or (at your option) any later version.              *
 *                                                                     *
 * This program is distributed in the hope that it will be useful,     *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of      *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
 * GNU General Public License for more details.                        *
 *                                                                     *
 * You should have received a copy of the GNU General Public License   *
 * along with this program; if not, write to the Free Software         *
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,          *
 * MA 02110-1301, USA.                                                 *
 *                                                                     *
 * Contributors:                                                       *
 * - Diego Ruiz - TrekGlobal           								   *
 **********************************************************************/
package org.idempiere.acct;

import org.compiere.model.MAcctSchema;
import org.idempiere.acct.doc.Doc;
import org.osgi.service.component.annotations.Component;

@Component(service = IDocPostingService.class, immediate = true)
public class DocPostingService implements IDocPostingService {

	@Override
	public String postImmediate(MAcctSchema[] ass, int AD_Table_ID, int Record_ID, boolean force, String trxName) {
		return Doc.postImmediate(ass, AD_Table_ID, Record_ID, force, trxName);
	}

	@Override
	public String manualPosting(int WindowNo, int AD_Client_ID, int AD_Table_ID, int Record_ID, boolean force) {
		return Doc.manualPosting(WindowNo, AD_Client_ID, AD_Table_ID, Record_ID, force);
	}

}
