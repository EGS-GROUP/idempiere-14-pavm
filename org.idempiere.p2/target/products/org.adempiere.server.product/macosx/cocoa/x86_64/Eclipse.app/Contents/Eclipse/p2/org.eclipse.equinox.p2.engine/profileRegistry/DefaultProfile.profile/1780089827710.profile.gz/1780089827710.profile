<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1780089827710'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64/Eclipse.app/Contents/Eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=macosx,osgi.arch=x86_64,osgi.ws=cocoa,osgi.nl=es_PE'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64/Eclipse.app/Contents/Eclipse'/>
  </properties>
</profile>
