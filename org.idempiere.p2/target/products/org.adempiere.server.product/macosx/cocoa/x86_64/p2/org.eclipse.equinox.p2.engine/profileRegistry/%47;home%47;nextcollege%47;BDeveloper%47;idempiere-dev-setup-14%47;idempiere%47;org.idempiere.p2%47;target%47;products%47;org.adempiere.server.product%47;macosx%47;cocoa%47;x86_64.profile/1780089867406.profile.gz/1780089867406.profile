<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64' timestamp='1780089867406'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=macosx,osgi.arch=x86_64,osgi.ws=cocoa,osgi.nl=es_PE'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64'/>
  </properties>
  <units size='27'>
    <unit id='a.jre.javase' version='17.0.0' singleton='false'>
      <provides size='256'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='17.0.0'/>
        <provided namespace='java.package' name='java.applet' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.desktop' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.zip' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='java.time' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.sctp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.beans' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jarsigner' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.event' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.logging' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.support' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.stream' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.chrono' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='java.math' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.geom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.swing.interop' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt' version='0.0.0'/>
        <provided namespace='java.package' name='java.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.prefs' version='0.0.0'/>
        <provided namespace='java.package' name='java.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='sun.misc' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.format' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.server' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.function' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image.renderable' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='javax.smartcardio' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.random' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker.support' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.dgc' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.http' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.invoke' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.catalog' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.management' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.atomic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.color' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.javadoc.doclet' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.registry' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.java.accessibility.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.management.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.constant' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.request' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.ref' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.instrument' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.regex' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='java.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.tool' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.jconsole' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.security.jarsigner' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='java.sql' version='0.0.0'/>
        <provided namespace='java.package' name='java.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.temporal' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.doctree' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.execution' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.javac' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.text.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.font' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.locks' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.nimbus' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio.mapmode' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr.consumer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.tiff' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='sun.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.module' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.zone' version='0.0.0'/>
        <provided namespace='java.package' name='netscape.javascript' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans.beancontext' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.module' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.io' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.jar' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.1.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.3.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.4.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.5.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.6.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.7.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='10.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='11.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='12.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='13.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='14.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='15.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='16.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='17.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='17.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='17.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='17.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='bcpg' version='1.81.0' singleton='false' generation='2'>
      <update id='bcpg' range='[0.0.0,1.81.0)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='bcpg'/>
        <property name='maven-groupId' value='org.bouncycastle'/>
        <property name='maven-artifactId' value='bcpg-jdk18on'/>
        <property name='maven-version' value='1.81'/>
        <property name='maven-repository' value='central'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='bcpg' version='1.81.0'/>
        <provided namespace='osgi.bundle' name='bcpg' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.apache.bzip2' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.bcpg' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.bcpg.attr' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.bcpg.sig' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.gpg' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.gpg.keybox' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.gpg.keybox.bc' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.gpg.keybox.jcajce' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.bc' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.exception' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.jcajce' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.util' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.bc' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.examples' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.jcajce' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.operator' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.operator.bc' version='1.81.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.operator.jcajce' version='1.81.0'/>
        <provided namespace='osgi.identity' name='bcpg' version='1.81.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='54'>
        <required namespace='java.package' name='java.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.math' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio.channels' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.interfaces' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.text' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.logging' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.regex' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.stream' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.zip' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.interfaces' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.bouncycastle.asn1' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.cryptlib' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.edec' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.gnu' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.nist' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.ntt' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.pkcs' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.sec' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.teletrust' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.x509' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.x9' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.agreement' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.digests' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.ec' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.encodings' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.engines' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.generators' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.io' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.modes' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.params' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.signers' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.util' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.io' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.util' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.provider.symmetric.util' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.spec' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.util' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jce.provider' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jce.spec' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.math.ec' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util.encoders' range='[1.81.0,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util.io' range='[1.81.0,1.82.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcpg
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcpg
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='bcpg.source' range='[1.81.0,1.81.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='bcpg' version='1.81.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: bcpg&#xA;Bundle-Version: 1.81
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='bcprov' version='1.81.1' singleton='false' generation='2'>
      <update id='bcprov' range='[0.0.0,1.81.1)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='bcprov'/>
        <property name='maven-groupId' value='org.bouncycastle'/>
        <property name='maven-artifactId' value='bcprov-jdk18on'/>
        <property name='maven-version' value='1.81.1'/>
        <property name='maven-repository' value='central'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='178'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='bcprov' version='1.81.1'/>
        <provided namespace='osgi.bundle' name='bcprov' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.anssi' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.bc' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cryptopro' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.gm' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.nist' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.ocsp' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.pkcs' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.sec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.teletrust' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.ua' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x500' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x500.style' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x509' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x509.qualified' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x509.sigi' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x9' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement.ecjpake' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement.jpake' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement.kdf' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement.srp' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.commitments' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.constraints' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.digests' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.ec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.encodings' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.engines' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.examples' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.fpe' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.generators' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.hpke' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.io' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.kems' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.macs' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.modes' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.modes.gcm' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.modes.kgcm' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.paddings' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.params' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.parsers' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.prng' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.prng.drbg' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.signers' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.threshold' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.tls' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.i18n' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.i18n.filter' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.iana' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.interfaces' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.io' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.compositesignatures' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.dh' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.dsa' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.dstu' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.ec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.ecgost' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.ecgost12' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.edec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.elgamal' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.gost' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.ies' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.mldsa' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.mlkem' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.rsa' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.slhdsa' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.x509' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.config' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.digest' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.drbg' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore.bc' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore.bcfks' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore.pkcs12' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.symmetric' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.symmetric.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.spec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jce' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jce.exception' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jce.interfaces' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jce.netscape' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jce.provider' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.jce.spec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.ldap' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.ec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.custom.djb' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.custom.gm' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.custom.sec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.endo' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.rfc7748' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.rfc8032' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.tools' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.field' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.math.raw' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.asn1' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.bike' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.cmce' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.crystals.dilithium' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.falcon' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.frodo' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.hqc' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.lms' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.mayo' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.mldsa' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.mlkem' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.newhope' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.ntru' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.ntruprime' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.picnic' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.rainbow' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.saber' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.slhdsa' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.snova' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.sphincs' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.sphincsplus' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.xmss' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.xwing' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.interfaces' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.bike' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.cmce' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.dilithium' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.falcon' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.frodo' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.gmss' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.hqc' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.kyber' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.lms' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.mayo' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.mceliece' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.newhope' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.ntru' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.ntruprime' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.picnic' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.saber' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.snova' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.sphincs' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.sphincsplus' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.xmss' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.spec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.crypto.gemss' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.crypto.gmss' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.crypto.gmss.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.crypto.mceliece' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.crypto.ntru' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.crypto.qtesla' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.math.linearalgebra' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.math.ntru.euclid' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.math.ntru.polynomial' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.math.ntru.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.math.ntru' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.math.ntru.parameters' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.util' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.util.encoders' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.util.io' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.util.io.pem' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.util.test' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.x509' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.x509.extension' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.x509.util' version='1.81.1'/>
        <provided namespace='osgi.identity' name='bcprov' version='1.81.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='31'>
        <required namespace='java.package' name='java.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang.ref' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.math' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio.channels' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio.charset' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.cert' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.interfaces' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.sql' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.text' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.concurrent' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.concurrent.atomic' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.logging' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.zip' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.interfaces' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming.directory' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.auth' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.auth.callback' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.auth.x500' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcprov
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcprov
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='bcprov.source' range='[1.81.1,1.81.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='bcprov' version='1.81.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: bcprov&#xA;Bundle-Version: 1.81.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='bcutil' version='1.81.1' singleton='false' generation='2'>
      <update id='bcutil' range='[0.0.0,1.81.1)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='bcutil'/>
        <property name='maven-groupId' value='org.bouncycastle'/>
        <property name='maven-artifactId' value='bcutil-jdk18on'/>
        <property name='maven-version' value='1.81.1'/>
        <property name='maven-repository' value='central'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='51'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='bcutil' version='1.81.1'/>
        <provided namespace='osgi.bundle' name='bcutil' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.bsi' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cmc' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cmp' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cms' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cms.ecc' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.crmf' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cryptlib' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.dvcs' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.eac' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.edec' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.esf' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.ess' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.est' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.gnu' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.iana' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.icao' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.isara' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.isismtt' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.isismtt.ocsp' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.isismtt.x509' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.iso' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.kisa' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.microsoft' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.misc' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.mozilla' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.nsri' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.ntt' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.oiw' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.rosstandart' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.smime' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.tsp' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.etsi102941' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.etsi102941.basetypes' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.etsi103097' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.etsi103097.extension' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.ieee1609dot2' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.ieee1609dot2.basetypes' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.ieee1609dot2dot1' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.etsi102941' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.etsi102941.basetypes' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.etsi103097' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.etsi103097.extension' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.ieee1609dot2' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.ieee1609dot2.basetypes' version='1.81.1'/>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.ieee1609dot2dot1' version='1.81.1'/>
        <provided namespace='osgi.identity' name='bcutil' version='1.81.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='java.package' name='java.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.math' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.text' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.bouncycastle.asn1' range='[1.81.1,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.nist' range='[1.81.1,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.ocsp' range='[1.81.1,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.pkcs' range='[1.81.1,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.x500' range='[1.81.1,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.x509' range='[1.81.1,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.math.ec' range='[1.81.1,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util' range='[1.81.1,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util.encoders' range='[1.81.1,1.82.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util.io' range='[1.81.1,1.82.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcutil
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcutil
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='bcutil.source' range='[1.81.1,1.81.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='bcutil' version='1.81.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: bcutil&#xA;Bundle-Version: 1.81.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.15.0.v20230808-1403' generation='2'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.15.0.v20230808-1403)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.jobs'/>
        <property name='maven-version' value='3.15.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.15.0.v20230808-1403'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.15.0.v20230808-1403'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.jobs' version='3.15.0.v20230808-1403'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.jobs
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.15.0.v20230808-1403'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.15.0.v20230808-1403
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.18.100.v20230730-1117' generation='2'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.18.100.v20230730-1117)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.common'/>
        <property name='maven-version' value='3.18.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.18.100.v20230730-1117'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.18.100.v20230730-1117'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='java.package' name='org.eclipse.core.text' version='3.13.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.common' version='3.18.100.v20230730-1117'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.17.200,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.common
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.18.100.v20230730-1117'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.18.100.v20230730-1117
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.artifact.repository' version='1.5.100.v20230630-1506-bcfips' generation='2'>
      <update id='org.eclipse.equinox.p2.artifact.repository' range='[0.0.0,1.5.100.v20230630-1506-bcfips)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Artifact Repository Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' version='1.5.100.v20230630-1506-bcfips'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.artifact.repository' version='1.5.100.v20230630-1506-bcfips'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.checksum' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.md5' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.pgp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.artifact.repository.processing' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.artifact.repository' version='1.5.100.v20230630-1506-bcfips'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='38'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.bouncycastle.bcpg' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.jce.provider' range='1.65.1' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.bc' range='1.65.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.jcajce' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator.bc' range='1.65.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator.jcajce' range='1.65.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.artifact.repository
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.source' range='[1.5.100.v20230630-1506-bcfips,1.5.100.v20230630-1506-bcfips]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.artifact.repository' version='1.5.100.v20230630-1506-bcfips'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.artifact.repository;singleton:=true&#xA;Bundle-Version: 1.5.100.v20230630-1506-bcfips
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.core' version='2.10.100.v20230814-2013' generation='2'>
      <update id='org.eclipse.equinox.p2.core' range='[0.0.0,2.10.100.v20230814-2013)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Core'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox.p2'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.core'/>
        <property name='maven-version' value='2.10.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' version='2.10.100.v20230814-2013'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' version='2.10.100.v20230814-2013'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core' version='2.8.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core.spi' version='2.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.core' version='2.10.100.v20230814-2013'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='java.package' name='org.bouncycastle.openpgp' range='1.65.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.8.0,2.9.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.core
          </description>
        </requiredProperties>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.1.0,2.2.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.bouncycastle.bcpg' range='1.65.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.core' version='2.10.100.v20230814-2013'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.core;singleton:=true&#xA;Bundle-Version: 2.10.100.v20230814-2013
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.director' version='2.6.100.v20230718-0609' generation='2'>
      <update id='org.eclipse.equinox.p2.director' range='[0.0.0,2.6.100.v20230718-0609)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Director'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox.p2'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.director'/>
        <property name='maven-version' value='2.6.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' version='2.6.100.v20230718-0609'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.director' version='2.6.100.v20230718-0609'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.rollback' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.planner' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.director' version='2.6.100.v20230718-0609'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='[2.3.5,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.pb' range='[2.3.5,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.director
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.director' version='2.6.100.v20230718-0609'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.director;singleton:=true&#xA;Bundle-Version: 2.6.100.v20230718-0609
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.engine' version='2.8.100.v20230630-1506' generation='2'>
      <update id='org.eclipse.equinox.p2.engine' range='[0.0.0,2.8.100.v20230630-1506)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Engine'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox.p2'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.engine'/>
        <property name='maven-version' value='2.8.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' version='2.8.100.v20230630-1506'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' version='2.8.100.v20230630-1506'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine' version='2.2.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.query' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.engine' version='2.8.100.v20230630-1506'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='39'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp' range='1.65.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.pgp' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.engine
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.engine' version='2.8.100.v20230630-1506'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.engine;singleton:=true&#xA;Bundle-Version: 2.8.100.v20230630-1506
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.jarprocessor' version='1.3.200.v20230630-1506' generation='2'>
      <update id='org.eclipse.equinox.p2.jarprocessor' range='[0.0.0,1.3.200.v20230630-1506)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning JAR Processor'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox.p2'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.jarprocessor'/>
        <property name='maven-version' value='1.3.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' version='1.3.200.v20230630-1506'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.jarprocessor' version='1.3.200.v20230630-1506'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.unsigner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.jarprocessor' version='1.3.200.v20230630-1506'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.jarprocessor
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.jarprocessor' version='1.3.200.v20230630-1506'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.jarprocessor;singleton:=true&#xA;Bundle-Version: 1.3.200.v20230630-1506
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata' version='2.7.100.v20230630-1506' generation='2'>
      <update id='org.eclipse.equinox.p2.metadata' range='[0.0.0,2.7.100.v20230630-1506)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox.p2'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.metadata'/>
        <property name='maven-version' value='2.7.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' version='2.7.100.v20230630-1506'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' version='2.7.100.v20230630-1506'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.query' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata' version='2.4.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.query' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.metadata' version='2.7.100.v20230630-1506'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.metadata
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata' version='2.7.100.v20230630-1506'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata;singleton:=true&#xA;Bundle-Version: 2.7.100.v20230630-1506
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata.repository' version='1.5.100.v20230630-1506' generation='2'>
      <update id='org.eclipse.equinox.p2.metadata.repository' range='[0.0.0,1.5.100.v20230630-1506)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox.p2'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.metadata.repository'/>
        <property name='maven-version' value='1.5.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' version='1.5.100.v20230630-1506'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' version='1.5.100.v20230630-1506'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.io' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.metadata.repository' version='1.5.100.v20230630-1506'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.metadata.repository
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata.repository' version='1.5.100.v20230630-1506'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata.repository;singleton:=true&#xA;Bundle-Version: 1.5.100.v20230630-1506
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.repository' version='2.7.100.v20230710-0621-bcfips' generation='2'>
      <update id='org.eclipse.equinox.p2.repository' range='[0.0.0,2.7.100.v20230710-0621-bcfips)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' version='2.7.100.v20230710-0621-bcfips'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' version='2.7.100.v20230710-0621-bcfips'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' version='2.3.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' version='2.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.repository' version='2.7.100.v20230710-0621-bcfips'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='34'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.3.0'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='org.bouncycastle' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.bcpg' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.gpg.keybox' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.gpg.keybox.jcajce' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.jcajce' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator.bc' range='1.72.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator.jcajce' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.util.encoders' range='1.72.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='3.2.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.security.storage' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.repository
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.source' range='[2.7.100.v20230710-0621-bcfips,2.7.100.v20230710-0621-bcfips]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.repository' version='2.7.100.v20230710-0621-bcfips'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.repository;singleton:=true&#xA;Bundle-Version: 2.7.100.v20230710-0621-bcfips
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.10.300.v20230630-1303' generation='2'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.10.300.v20230630-1303)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.preferences'/>
        <property name='maven-version' value='3.10.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.10.300.v20230630-1303'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.10.300.v20230630-1303'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.5.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.preferences' version='3.10.300.v20230630-1303'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.prefs' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.preferences
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.10.300.v20230630-1303'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.10.300.v20230630-1303
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.11.300.v20230801-1826' generation='2'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.11.300.v20230801-1826)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.registry'/>
        <property name='maven-version' value='3.11.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.11.300.v20230801-1826'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.11.300.v20230801-1826'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.registry' version='3.11.300.v20230801-1826'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.15.100,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.registry
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.11.300.v20230801-1826'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.11.300.v20230801-1826
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security' version='1.4.0.v20230630-1303' generation='2'>
      <update id='org.eclipse.equinox.security' range='[0.0.0,1.4.0.v20230630-1303)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Java Authentication and Authorization Service (JAAS)'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.security'/>
        <property name='maven-version' value='1.4.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' version='1.4.0.v20230630-1303'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security' version='1.4.0.v20230630-1303'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.ext.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.credentials' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.friends' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.credentials' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.module' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage.provider' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.security' version='1.4.0.v20230630-1303'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.callback' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.login' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.spi' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.security
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security' version='1.4.0.v20230630-1303'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security;singleton:=true&#xA;Bundle-Version: 1.4.0.v20230630-1303
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator' version='1.4.300.v20230630-1506' generation='2'>
      <update id='org.eclipse.equinox.simpleconfigurator' range='[0.0.0,1.4.300.v20230630-1506)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleName' value='Simple Configurator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox.p2'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.simpleconfigurator'/>
        <property name='maven-version' value='1.4.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' version='1.4.300.v20230630-1506'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' version='1.4.300.v20230630-1506'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.simpleconfigurator' version='1.4.300.v20230630-1506'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.equinox.simpleconfigurator
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator' version='1.4.300.v20230630-1506'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator;singleton:=true&#xA;Bundle-Version: 1.4.300.v20230630-1506
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.18.500.v20230801-1826' generation='2'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.18.500.v20230801-1826)' severity='0'/>
      <properties size='11'>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
        <property name='maven-groupId' value='org.eclipse.osgi'/>
        <property name='maven-artifactId' value='org.eclipse.osgi'/>
        <property name='maven-version' value='3.18.500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='97'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.18.500.v20230801-1826'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.18.500.v20230801-1826'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container' version='1.6.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.builders' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.namespaces' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.framework' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.hookregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.classpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.sources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.messages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.report.resolution' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.6.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.url.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.dto' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.10.0'/>
        <provided namespace='java.package' name='org.osgi.framework.connect' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.dto' version='1.8.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.namespace' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring.dto' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.resource' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.resource.dto' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.service.condition' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.2'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.log.admin' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.resolver' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.3'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi' version='3.18.500.v20230801-1826'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LogReaderService,org.eclipse.equinox.log.ExtendedLogReaderService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LoggerFactory,org.osgi.service.log.LogService,org.eclipse.equinox.log.ExtendedLogService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-3' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.admin.LoggerAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-4' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.framework.log.FrameworkLog' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-5' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.user.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-6' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.instance.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-7' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.configuration.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-8' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.install.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-9' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='eclipse.home.location'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-10' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.environment.EnvironmentInfo' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-11' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.packageadmin.PackageAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-12' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.startlevel.StartLevel' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-13' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.permissionadmin.PermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-14' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.condpermadmin.ConditionalPermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-15' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.resolver.Resolver' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-16' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.debug.DebugOptions' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-17' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.urlconversion.URLConverter' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-18' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.localization.BundleLocalization' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-19' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.security.TrustEngine' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-20' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.signedcontent.SignedContentFactory' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.18.500.v20230801-1826-21' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.osgi.service.condition.Condition' type='List'/>
            <property name='osgi.condition.id' value='true'/>
          </properties>
        </provided>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.connect.ConnectFrameworkFactory' version='0.0.0'/>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.launch.FrameworkFactory' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(version=1.8)(|(osgi.ee=JavaSE)(osgi.ee=JavaSE/compact1)))'>
          <description>
            org.eclipse.osgi
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.18.500.v20230801-1826'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.18.500.v20230801-1826
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.idempiere.equinox.p2.director.feature.feature.group' version='14.0.0.202605292120' singleton='false'>
      <update id='org.idempiere.equinox.p2.director.feature.feature.group' range='[0.0.0,14.0.0.202605292120)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Idempiere P2 Director'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.provider' value='www.idempiere.org'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.idempiere'/>
        <property name='maven-artifactId' value='org.idempiere.equinox.p2.director.feature'/>
        <property name='maven-version' value='14.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature.feature.group' version='14.0.0.202605292120'/>
      </provides>
      <requires size='9'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature.feature.jar' range='[14.0.0.202605292120,14.0.0.202605292120]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root.win32.win32.x86' range='[14.0.0.202605292120,14.0.0.202605292120]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root.gtk.linux.x86' range='[14.0.0.202605292120,14.0.0.202605292120]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root.cocoa.macosx.x86' range='[14.0.0.202605292120,14.0.0.202605292120]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root.cocoa.macosx.x86_64' range='[14.0.0.202605292120,14.0.0.202605292120]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root.gtk.linux.x86_64' range='[14.0.0.202605292120,14.0.0.202605292120]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root.gtk.solaris.x86' range='[14.0.0.202605292120,14.0.0.202605292120]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root.win32.win32.x86_64' range='[14.0.0.202605292120,14.0.0.202605292120]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root' range='[14.0.0.202605292120,14.0.0.202605292120]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='org.idempiere.equinox.p2.director.feature.feature.jar' version='14.0.0.202605292120'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='Idempiere P2 Director'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.provider' value='www.idempiere.org'/>
        <property name='maven-groupId' value='org.idempiere'/>
        <property name='maven-artifactId' value='org.idempiere.equinox.p2.director.feature'/>
        <property name='maven-version' value='14.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature.feature.jar' version='14.0.0.202605292120'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.idempiere.equinox.p2.director.feature' version='14.0.0.202605292120'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.idempiere.equinox.p2.director.feature' version='14.0.0.202605292120'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='org.idempiere.equinox.p2.director.feature_root' version='14.0.0.202605292120'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root' version='14.0.0.202605292120'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.idempiere.equinox.p2.director.feature_root' version='14.0.0.202605292120'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.idempiere.equinox.p2.director.feature_root.cocoa.macosx.x86_64' version='14.0.0.202605292120'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.idempiere.equinox.p2.director.feature_root.cocoa.macosx.x86_64' version='14.0.0.202605292120'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.idempiere.equinox.p2.director.feature_root.cocoa.macosx.x86_64' version='14.0.0.202605292120'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='9'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:compare-update-prd.sh, permissions:755);
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:director.sh, permissions:755);
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:update.sh, permissions:755);
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:update-prd.sh, permissions:755);
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:compare-update-prd.sh, permissions:755);
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:director.sh, permissions:755);
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:update.sh, permissions:755);
          </instruction>
        </instructions>
        <instructions size='1'>
          <instruction key='install'>
            chmod(targetDir:${installFolder}, targetFile:update-prd.sh, permissions:755);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.prefs' version='1.1.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.prefs' range='[0.0.0,1.1.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.prefs'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.prefs Version 1.1.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.prefs'/>
        <property name='maven-version' value='1.1.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.2'/>
        <provided namespace='osgi.identity' name='org.osgi.service.prefs' version='1.1.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.prefs
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.prefs' version='1.1.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.prefs&#xA;Bundle-Version: 1.1.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.core' version='2.3.6.v20201214' singleton='false' generation='2'>
      <update id='org.sat4j.core' range='[0.0.0,2.3.6.v20201214)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.ow2.sat4j'/>
        <property name='maven-artifactId' value='org.ow2.sat4j.core'/>
        <property name='maven-version' value='2.3.6'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' version='2.3.6.v20201214'/>
        <provided namespace='osgi.bundle' name='org.sat4j.core' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.core' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.card' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.cnf' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.core' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.learning' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.orders' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.restarts' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.opt' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.reader' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.specs' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.tools' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.tools.encoding' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.tools.xplain' version='2.3.6.v20201214'/>
        <provided namespace='osgi.identity' name='org.sat4j.core' version='2.3.6.v20201214'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.sat4j.core
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.core' version='2.3.6.v20201214'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.core&#xA;Bundle-Version: 2.3.6.v20201214
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.pb' version='2.3.6.v20201214' singleton='false' generation='2'>
      <update id='org.sat4j.pb' range='[0.0.0,2.3.6.v20201214)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.ow2.sat4j'/>
        <property name='maven-artifactId' value='org.ow2.sat4j.pb'/>
        <property name='maven-version' value='2.3.6'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' version='2.3.6.v20201214'/>
        <provided namespace='osgi.bundle' name='org.sat4j.pb' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints.pb' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.core' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.orders' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.reader' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.tools' version='2.3.6.v20201214'/>
        <provided namespace='osgi.identity' name='org.sat4j.pb' version='2.3.6.v20201214'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.sat4j.pb
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.pb' version='2.3.6.v20201214'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.pb&#xA;Bundle-Version: 2.3.6.v20201214
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.tukaani.xz' version='1.9.0' singleton='false'>
      <update id='org.tukaani.xz' range='[0.0.0,1.9.0)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='XZ data compression'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://tukaani.org/xz/java.html'/>
        <property name='maven-groupId' value='org.tukaani'/>
        <property name='maven-artifactId' value='xz'/>
        <property name='maven-version' value='1.9'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' version='1.9.0'/>
        <provided namespace='osgi.bundle' name='org.tukaani.xz' version='1.9.0'/>
        <provided namespace='java.package' name='org.tukaani.xz' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.tukaani.xz' version='1.9.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.tukaani.xz' version='1.9.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.tukaani.xz&#xA;Bundle-Version: 1.9
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='27'>
    <iuProperties id='org.eclipse.equinox.p2.director' version='2.6.100.v20230718-0609'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.idempiere.equinox.p2.director.feature.feature.group' version='14.0.0.202605292120'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.idempiere.equinox.p2.director.feature_root' version='14.0.0.202605292120'>
      <properties size='1'>
        <property name='unzipped|@artifact|/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64' value='/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64/director|/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64/director/configuration|/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64/director/configuration/config.ini|'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.idempiere.equinox.p2.director.feature_root.cocoa.macosx.x86_64' version='14.0.0.202605292120'>
      <properties size='1'>
        <property name='unzipped|@artifact|/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64' value='/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64/update.sh|/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64/director.sh|/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64/update-prd.sh|/home/nextcollege/BDeveloper/idempiere-dev-setup-14/idempiere/org.idempiere.p2/target/products/org.adempiere.server.product/macosx/cocoa/x86_64/compare-update-prd.sh|'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
